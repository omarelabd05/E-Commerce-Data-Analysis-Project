import streamlit as st
from io import BytesIO
import pandas as pd

from db import get_connection
import kpis

# =========================
# PAGE CONFIG
# =========================
st.set_page_config(
    page_title="E-Commerce KPI Dashboard",
    layout="wide"
)

# =========================
# TITLE + TEAM LABEL
# =========================
st.title("📊 E-Commerce KPI Dashboard")

col_left, col_right = st.columns([8, 4])

with col_right:
    st.markdown(
        """
        <div style="
            background-color:#f0f2f6;
            padding:12px;
            border-radius:12px;
            text-align:center;
            font-size:13px;
            color:#333;
        ">
            <b>Team Members</b><br>
            Mustafa Hussein • Nadeen Elnasharty • Omar Elabd<br>
            Marwa Nasser • Yasmine
            <hr style="margin:8px 0;">
            <span style="font-size:12px; color:gray;">
                <b>IEEE Submission</b><br>
                Seif • Hadir • Nusybaa
            </span>
        </div>
        """,
        unsafe_allow_html=True
    )

# =========================
# ARABIC OVERVIEW NLQ
# =========================
OVERVIEW_MAP = {
    "revenue": {
        "keywords": ["ايراد", "ايرادات", "دخل", "revenue"],
        "label": "Total Revenue",
        "formatter": lambda x: f"${x:,.0f}"
    },
    "orders": {
        "keywords": ["اوردر", "طلبات", "orders"],
        "label": "Orders",
        "formatter": lambda x: int(x)
    },
    "customers": {
        "keywords": ["عملاء", "customers"],
        "label": "Customers",
        "formatter": lambda x: int(x)
    },
    "aov": {
        "keywords": ["متوسط", "متوسط الطلب", "aov"],
        "label": "AOV",
        "formatter": lambda x: f"${x:,.2f}"
    },
    "cancellation": {
        "keywords": ["الغاء", "الغاء الطلب", "cancellation"],
        "label": "Cancellation Rate (%)",
        "formatter": lambda x: f"{x}%"
    }
}

def detect_overview_metric(text):
    text = text.lower().strip()
    for key, meta in OVERVIEW_MAP.items():
        if any(k in text for k in meta["keywords"]):
            return key
    return None


# =========================
# EXPORT FUNCTION
# =========================
def export_all_kpis_to_excel(conn):
    output = BytesIO()

    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        kpis.overview_kpis(conn).to_excel(writer, "Overview", index=False)

        monthly = kpis.monthly_sales_trend(conn)
        monthly["period"] = (
            monthly["year"].astype(str) + "-" +
            monthly["month"].astype(str).str.zfill(2)
        )
        monthly.to_excel(writer, "Monthly_Sales", index=False)

        kpis.running_monthly_revenue(conn).to_excel(writer, "Running_Revenue", index=False)
        kpis.top_selling_products(conn).to_excel(writer, "Top_Products", index=False)
        kpis.revenue_per_category(conn).to_excel(writer, "Revenue_By_Category", index=False)
        kpis.return_rate_per_product(conn).to_excel(writer, "Return_Rate", index=False)
        kpis.average_rating_per_product(conn).to_excel(writer, "Ratings", index=False)
        kpis.top_customers(conn).to_excel(writer, "Top_Customers", index=False)
        kpis.avg_shipping_cost_per_city(conn).to_excel(writer, "Shipping_Cost", index=False)
        kpis.best_day_of_week(conn).to_excel(writer, "Best_Day", index=False)
        kpis.customers_with_no_orders(conn).to_excel(writer, "Customers_No_Orders", index=False)
        kpis.products_never_ordered(conn).to_excel(writer, "Products_Never_Ordered", index=False)
        kpis.payment_method_usage(conn).to_excel(writer, "Payment_Methods", index=False)
        kpis.cities_by_orders(conn).to_excel(writer, "Cities_By_Orders", index=False)

    output.seek(0)
    return output


# =========================
# DB CONNECTION
# =========================
conn = get_connection()

# =========================
# TABS
# =========================
tab_overview, tab_products, tab_customers, tab_analysis = st.tabs(
    ["📊 Overview", "📦 Products", "👥 Customers", "🔍 Analysis"]
)

# =========================
# OVERVIEW TAB
# =========================
with tab_overview:
    st.header("Overview")

    overview = kpis.overview_kpis(conn)

    st.subheader("📊 استعلم عن بيانات المتجر")

    question = st.text_input(
        "Example: total revenue – number of customers – overview",
        key="overview_nlq"
    )

    if question:
        q = question.lower().strip()

        if any(k in q for k in ["overview", "ملخص", "الداشبورد"]):
            st.success("📊 ملخص بيانات المتجر")

            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Total Revenue", f"${overview.total_revenue[0]:,.0f}")
            c2.metric("Orders", int(overview.total_orders[0]))
            c3.metric("Customers", int(overview.total_customers[0]))
            c4.metric("AOV", f"${overview.avg_order_value[0]:,.2f}")

            st.metric(
                "Cancellation Rate (%)",
                f"{overview.cancellation_rate_pct[0]}%"
            )
        else:
            metric = detect_overview_metric(q)

            if metric:
                row = overview.iloc[0]
                value_map = {
                    "revenue": row.total_revenue,
                    "orders": row.total_orders,
                    "customers": row.total_customers,
                    "aov": row.avg_order_value,
                    "cancellation": row.cancellation_rate_pct
                }
                meta = OVERVIEW_MAP[metric]
                st.metric(meta["label"], meta["formatter"](value_map[metric]))
            else:
                st.warning("❌ مش فاهم سؤالك، جرّب صيغة تانية")

    st.subheader("Monthly Revenue")
    monthly = kpis.monthly_sales_trend(conn)
    monthly["period"] = (
        monthly["year"].astype(str) + "-" +
        monthly["month"].astype(str).str.zfill(2)
    )
    st.line_chart(monthly.set_index("period")["revenue"])

    st.subheader("Running Revenue")
    running = kpis.running_monthly_revenue(conn)
    running["period"] = (
        running["year"].astype(str) + "-" +
        running["month"].astype(str).str.zfill(2)
    )
    st.area_chart(running.set_index("period")["running_total"])


# =========================
# PRODUCTS TAB
# =========================
with tab_products:
    st.header("Products")

    st.subheader("Top Selling Products")
    st.dataframe(kpis.top_selling_products(conn), use_container_width=True)

    st.subheader("Revenue by Category")
    category_rev = kpis.revenue_per_category(conn)
    st.bar_chart(category_rev.set_index("category")["revenue"])

    st.subheader("Return Rate per Product")
    st.dataframe(kpis.return_rate_per_product(conn), use_container_width=True)

    st.subheader("Average Rating per Product")
    st.dataframe(kpis.average_rating_per_product(conn), use_container_width=True)


# =========================
# CUSTOMERS TAB
# =========================
with tab_customers:
    st.header("Customers")

    st.subheader("Top Customers")
    st.dataframe(kpis.top_customers(conn), use_container_width=True)

    st.subheader("Average Shipping Cost per City")
    st.dataframe(kpis.avg_shipping_cost_per_city(conn), use_container_width=True)

    st.subheader("Best Day of the Week")
    st.dataframe(kpis.best_day_of_week(conn), use_container_width=True)


# =========================
# ANALYSIS TAB
# =========================
with tab_analysis:
    st.header("Analysis (Deep Dive)")

    st.subheader("Customers With No Orders")
    st.dataframe(kpis.customers_with_no_orders(conn), use_container_width=True)

    st.subheader("Products Never Ordered")
    st.dataframe(kpis.products_never_ordered(conn), use_container_width=True)

    st.subheader("Payment Method Usage")
    st.dataframe(kpis.payment_method_usage(conn), use_container_width=True)

    st.subheader("Cities by Number of Orders")
    st.dataframe(kpis.cities_by_orders(conn), use_container_width=True)


# =========================
# EXPORT
# =========================
st.divider()
st.header("⬇️ Export Data")

if st.button("📦 Generate KPI Excel Report"):
    with st.spinner("Generating Excel file..."):
        excel_file = export_all_kpis_to_excel(conn)

    st.download_button(
        label="📥 Download KPI Report (Excel)",
        data=excel_file,
        file_name="ecommerce_kpis.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

conn.close()
