import pandas as pd

# =========================
# OVERVIEW
# =========================
def overview_kpis(conn):
    query = """
    SELECT 
        COUNT(DISTINCT o.orderID) AS total_orders,
        COUNT(DISTINCT o.user_id) AS total_customers,
        SUM(DISTINCT pay.amount) AS total_revenue,
        AVG(DISTINCT pay.amount) AS avg_order_value,
        SUM(od.quantity) AS total_items_sold,
        CAST(
            COUNT(DISTINCT CASE WHEN o.Status = 'cancelled' THEN o.orderID END) 
            * 100.0 / COUNT(DISTINCT o.orderID)
            AS DECIMAL(5,2)
        ) AS cancellation_rate_pct
    FROM [Order] o
    JOIN Payment pay ON o.orderID = pay.Order_id
    LEFT JOIN OrderDetails od ON o.orderID = od.order_id
    WHERE pay.status = 'completed';
    """
    return pd.read_sql(query, conn)

# =========================
# SALES
# =========================
def monthly_sales_trend(conn):
    query = """
    SELECT 
        YEAR(o.order_created_at) AS year,
        MONTH(o.order_created_at) AS month,
        SUM(od.quantity * od.unit_price) AS revenue
    FROM [Order] o
    JOIN OrderDetails od ON o.orderID = od.order_id
    GROUP BY YEAR(o.order_created_at), MONTH(o.order_created_at)
    ORDER BY year, month;
    """
    return pd.read_sql(query, conn)


def running_monthly_revenue(conn):
    query = """
    WITH m AS (
        SELECT 
            YEAR(o.order_created_at) AS year,
            MONTH(o.order_created_at) AS month,
            SUM(od.quantity * od.unit_price) AS revenue
        FROM [Order] o
        JOIN OrderDetails od ON o.orderID = od.order_id
        GROUP BY YEAR(o.order_created_at), MONTH(o.order_created_at)
    )
    SELECT *, SUM(revenue) OVER (ORDER BY year, month) AS running_total
    FROM m;
    """
    return pd.read_sql(query, conn)

# =========================
# PRODUCTS
# =========================
def top_selling_products(conn):
    query = """
    SELECT TOP 10 p.Name, SUM(od.quantity) AS total_sold
    FROM Product p
    JOIN OrderDetails od ON p.productID = od.product_id
    GROUP BY p.Name
    ORDER BY total_sold DESC;
    """
    return pd.read_sql(query, conn)


def revenue_per_category(conn):
    query = """
    SELECT c.Name AS category, SUM(od.quantity * od.unit_price) AS revenue
    FROM Category c
    JOIN Product p ON c.categoryID = p.category_ID
    JOIN OrderDetails od ON p.productID = od.product_id
    GROUP BY c.Name
    ORDER BY revenue DESC;
    """
    return pd.read_sql(query, conn)


def return_rate_per_product(conn):
    query = """
    SELECT 
        p.Name,
        SUM(ISNULL(r.returned_quantity, 0)) AS returned_qty,
        SUM(od.quantity) AS sold_qty,
        CAST(
            SUM(ISNULL(r.returned_quantity, 0)) * 100.0 /
            NULLIF(SUM(od.quantity), 0)
            AS DECIMAL(5,2)
        ) AS return_rate_pct
    FROM Product p
    JOIN OrderDetails od ON p.productID = od.product_id
    LEFT JOIN [Return] r 
        ON r.product_id = od.product_id 
       AND r.order_id = od.order_id
    GROUP BY p.Name
    ORDER BY return_rate_pct DESC;
    """
    return pd.read_sql(query, conn)


def average_rating_per_product(conn):
    query = """
    SELECT 
        p.Name,
        ROUND(AVG(r.rating), 2) AS avg_rating,
        COUNT(r.ReviewID) AS total_reviews
    FROM Product p
    LEFT JOIN Review r ON p.productID = r.Product_id
    GROUP BY p.Name
    ORDER BY avg_rating DESC;
    """
    return pd.read_sql(query, conn)

# =========================
# CUSTOMERS & OPS
# =========================
def top_customers(conn):
    query = """
    SELECT TOP 5
        u.First_name + ' ' + u.Last_name AS customer_name,
        SUM(od.quantity * od.unit_price) AS total_spent
    FROM [User] u
    JOIN [Order] o ON u.UserID = o.user_id
    JOIN OrderDetails od ON o.orderID = od.order_id
    GROUP BY u.First_name, u.Last_name
    ORDER BY total_spent DESC;
    """
    return pd.read_sql(query, conn)


def avg_shipping_cost_per_city(conn):
    query = """
    SELECT a.city, ROUND(AVG(o.shipping_cost), 2) AS avg_shipping_cost
    FROM [Order] o
    JOIN Address a ON o.shipping_address_id = a.Address_id
    GROUP BY a.city
    ORDER BY avg_shipping_cost DESC;
    """
    return pd.read_sql(query, conn)


def best_day_of_week(conn):
    query = """
    SELECT 
        DATENAME(WEEKDAY, o.order_created_at) AS day,
        SUM(pay.amount) AS revenue
    FROM [Order] o
    JOIN Payment pay ON o.orderID = pay.Order_id
    WHERE pay.status = 'completed'
    GROUP BY DATENAME(WEEKDAY, o.order_created_at)
    ORDER BY revenue DESC;
    """
    return pd.read_sql(query, conn)

# =========================
# ANALYSIS
# =========================
def customers_with_no_orders(conn):
    query = """
    SELECT u.UserID, u.First_name, u.Last_name
    FROM [User] u
    LEFT JOIN [Order] o ON u.UserID = o.user_id
    WHERE o.orderID IS NULL;
    """
    return pd.read_sql(query, conn)


def products_never_ordered(conn):
    query = """
    SELECT productID, Name, price, Brand
    FROM Product
    WHERE productID NOT IN (
        SELECT DISTINCT product_id FROM OrderDetails
    );
    """
    return pd.read_sql(query, conn)


def payment_method_usage(conn):
    query = """
    SELECT method, COUNT(*) AS usage_count
    FROM Payment
    GROUP BY method
    ORDER BY usage_count DESC;
    """
    return pd.read_sql(query, conn)


def cities_by_orders(conn):
    query = """
    SELECT a.city, COUNT(o.orderID) AS orders_count
    FROM Address a
    JOIN [Order] o ON a.Address_id = o.shipping_address_id
    GROUP BY a.city
    ORDER BY orders_count DESC;
    """
    return pd.read_sql(query, conn)
